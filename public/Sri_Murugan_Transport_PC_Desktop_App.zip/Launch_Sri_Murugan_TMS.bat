@echo off
chcp 65001 >nul
title Sri Murugan Transport - TMS Desktop
echo ============================================================
echo   SRI MURUGAN TRANSPORT - OFFLINE PC APPLICATION
echo   100% Offline Local Disk Storage - No Cloud / No Internet
echo ============================================================
echo.
echo Launching Sri Murugan Transport in Desktop App Window...
echo.

where msedge >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" msedge --app="%~dp0index.html" --allow-file-access-from-files
    exit
)

where chrome >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" chrome --app="%~dp0index.html" --allow-file-access-from-files
    exit
)

start "" "%~dp0index.html"
exit
