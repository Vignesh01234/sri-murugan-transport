============================================================
SRI MURUGAN TRANSPORT - OFFLINE PC DESKTOP APP
============================================================

Thank you for downloading Sri Murugan Transport Management System.
This edition is designed to run 100% OFFLINE on your local PC disk without any cloud storage or internet connection.

HOW TO RUN:
1. Extract all files from this ZIP to a folder on your computer (e.g. Desktop or C:\SriMuruganTMS).
2. Double-click "Launch_Sri_Murugan_TMS.bat" to open the application in a standalone desktop window.
3. You can right-click "Launch_Sri_Murugan_TMS.bat" -> "Send to" -> "Desktop (create shortcut)" to have an icon on your desktop!

LOGIN CREDENTIALS (Pre-configured for Offline PC):
- Administrator: Username: admin | Password: admin (or PIN: 1234)
- Booking Staff: Username: staff1 | Password: staff (or PIN: 1234)
- Accountant:    Username: accounts | Password: accounts (or PIN: 1234)
- Guest Viewer:  Username: viewer | Password: viewer (or PIN: 1234)

OFFLINE DATA & BACKUP:
- All LRs, parties, payments, and vehicles are stored directly on your computer's local disk.
- Whenever you exit or click 'Local Disk Backup' in the top-right corner, you can export a full backup JSON file.
